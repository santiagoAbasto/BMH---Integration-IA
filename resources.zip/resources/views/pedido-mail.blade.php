<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</head>
<body>
    <main>
        @isset($empresa)
        <section>
            <p>Mensaje del cliente</p>
            {{ $pedido->notas }}
        </section>
        @endisset

        <section>
            {!! $mensaje !!}
        </section>
        <section>
            <div>Orden: #{{$pedido->id}}</div><br>
            <div>Productos:</div>
            @include('backend/components/pedido-tabla')
        </section>
    </main>
</body>
</html>